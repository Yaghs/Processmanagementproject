/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.c to edit this template
 */

#include "processManagement.h"
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

int processTimerInterrupt(processStructure* ps) {
    return -1;
}
void processScheduleInitialize(processStructure* ps)  {
}
int processAdd(processStructure*ps, int parent){
    return -1;
}
int processGetRunningPID(processStructure* ps){
    return -1;
}
int processIORequest(processStructure* ps){
    return -1;
}
int processIODone(processStructure* ps, int processID){
    return -1;
}
int processWaitFor(processStructure* ps, int processID){
    return -1;
}
int processExit(processStructure* ps, int processID) {
    return -1;
}
processState getProcessStatus(processStructure* ps, int processID) {
    return UNUSED;
}
