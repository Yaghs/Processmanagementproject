/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/main.c to edit this template
 */

/* 
 * File:   main.c
 * Author: student
 *
 * Created on February 26, 2023, 1:04 PM
 */

#include "processManagement.h"
#include "processTestCode.h"
#include <stdio.h>
#include <stdlib.h>

/*
 * 
 */
int main(int argc, char** argv) {
    int result1 = processTestOne();
    int result2 = processTestTwo();
    int result3 = processTestThree();
    

    if (result1 == 0 && result2 == 0 && result3 == 0) {
        printf("All test cases passed.\n");
    } else {
        printf("Some test cases failed.\n");
    }

    return 0;
}



