#include "processManagement.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Initialize the process scheduler
void processScheduleInitialize(processStructure* ps) {
    ps->processCount = 0;
    ps->runningProcess = -1;  // No process running initially

    // Initialize the process data structures
    for (int i = 0; i < PROCESS_MAX; i++) {
        ps->processes[i].pid = -1;  // Initialize process IDs to -1 indicating no process
        ps->processes[i].state = UNUSED;  // Set all processes to UNUSED state
    }
}

// Add a new process
int processAdd(processStructure* ps, int parent) {
    if (ps->processCount >= PROCESS_MAX) {
        return -1;  // Maximum processes reached
    }

    for (int i = 0; i < PROCESS_MAX; i++) {
        if (ps->processes[i].state == UNUSED) {
            // Find the next available PID
            int nextPID = 0;
            int found = 0;

            // Find the next available PID that is not in use
            while (nextPID < PROCESS_MAX) {
                found = 0;
                for (int j = 0; j < ps->processCount; j++) {
                    if (ps->processes[j].pid == nextPID) {
                        found = 1;
                        break;
                    }
                }

                if (!found) {
                    break;
                }
                nextPID++;
            }

            if (nextPID >= PROCESS_MAX) {
                return -1;  // All PIDs are in use
            }

            // Initialize the new process
            ps->processes[i].pid = nextPID;  // Assign PID
            ps->processes[i].parent = parent;
            ps->processes[i].state = EMBRYO;
            ps->processCount++;

            // Check if no process is currently running, set the new one to RUNNING
            if (ps->runningProcess == -1) {
                ps->runningProcess = i;
                ps->processes[i].state = RUNNING;
            } else {
                ps->processes[i].state = RUNNABLE;  // Set state to RUNNABLE
            }

            return nextPID;  // Return the assigned PID
        }
    }
    return -1;  // Process not added
}

// Handle process timer interrupt
int processTimerInterrupt(processStructure* ps) {
    // Simple round robin scheduling for now.
    int current = ps->runningProcess;
    int next = (current + 1) % PROCESS_MAX;

    // Check if there are any RUNNABLE or BLOCKED processes
    int runnableProcessFound = 0;
    int originalNext = next;

    // Find the next RUNNABLE or BLOCKED process, starting from the current
    do {
        if (ps->processes[next].state == READY || ps->processes[next].state == BLOCKED) {
            runnableProcessFound = 1;
            break;
        }
        next = (next + 1) % PROCESS_MAX;
    } while (next != originalNext);

    if (runnableProcessFound) {
        // If a RUNNABLE or BLOCKED process is found, update the running process
        ps->runningProcess = next;
        ps->processes[next].state = RUNNING;
        return next;  // Return the PID of the running process
    } else {
        // No RUNNABLE or BLOCKED processes found, stay in the current process
        return current;
    }
}

// Handle process IO request
int processIORequest(processStructure* ps) {
    processStructure* processSystem = (processStructure*)ps;

    int currentProcessID = processGetRunningPID(ps);
// checks if there is a currently running process
    if (currentProcessID != -1) {
        // Set the currently running process to READY
        //loop through all of the processes within the system
        for (int i = 0; i < processSystem->processCount; i++) {
            //check if the current process in the loop shares the same PID with the running process
            if (processSystem->processes[i].pid == currentProcessID) {
                // Set the state of the current process to READY, indicating it's ready to run again.
                processSystem->processes[i].state = READY;
                // Print a message to indicate that the process with a specific PID is now READY.

                printf("Process %d is now READY.\n", processSystem->processes[i].pid);
                break;
                 // Once the state of the running process is set to READY, exit the loop.
        }
    }
}
               

    // Check if there is a process waiting for I/O (BLOCKED state)
    int ioWaitingProcessID = -1;
    for (int i = 0; i < processSystem->processCount; i++) {
        if (processSystem->processes[i].state == BLOCKED) {
            ioWaitingProcessID = i;
            break;
        }
    }

    if (ioWaitingProcessID != -1) {
        // If there is a process waiting for I/O, schedule it
        ps->runningProcess = ioWaitingProcessID;
        ps->processes[ioWaitingProcessID].state = RUNNING;
    } else {
        // If no process is waiting for I/O, use the timer interrupt logic
        int nextProcessID = processTimerInterrupt(ps);

        // Only set the state to BLOCKED if there is a valid next process
        if (nextProcessID != -1) {
            ps->processes[ps->runningProcess].state = BLOCKED;
        }
    }

    return 0; 
}

// Handle IO completion for a process
int processIODone(processStructure* ps, int processID) {
    if (processID >= 0 && processID < PROCESS_MAX && ps->processes[processID].state == BLOCKED) {
        ps->processes[processID].state = READY;
        return 0;
    }
    return -1;  // Invalid processID or process not in BLOCKED state
}

// Handle waiting for a specific process
int processWaitFor(processStructure* ps, int processID) {
// Check if there is a currently running process (ps->runningProcess is not -1)
    if (ps->runningProcess != -1) {
        // Check if the provided processID is within valid bounds, and the process with that ID is not in the UNUSED state.
        if (processID >= 0 && processID < PROCESS_MAX && ps->processes[processID].state != UNUSED) {
             // Set the state of the currently running process (ps->runningProcess) to BLOCKED.
               // This action blocks the currently running process, preventing it from executing further.
            ps->processes[ps->runningProcess].state = BLOCKED;
            processTimerInterrupt(ps);  // Preempt the currently running process
            return 0;
        }
    }
    return -1;  // Invalid processID or no running process to block
}

// Handle process exit
int processExit(processStructure* ps, int processID) {
    if (processID >= 0 && processID < PROCESS_MAX) {
        //check if the given processID is within valid range/bounds 
        ps->processes[processID].state = ZOMBIE;
        //sets the state of the pricess with the given processID to ZOMBIE
        //AKA the process has stopped working but it is still present and to remove it one has to delete it from the source
        if (ps->runningProcess == processID) {
            processTimerInterrupt(ps);  // Preempt the exiting process
        }
        return 0;
    }
    return -1;  // Invalid processID
}

// Get the currently running process's PID
int processGetRunningPID(processStructure* ps) {
    return ps->runningProcess;
}

// Get the status of a process
processState getProcessStatus(processStructure* ps, int processID) {
    if (processID >= 0 && processID < PROCESS_MAX) {
        return ps->processes[processID].state;
    }
    return UNUSED;  // Process ID not found
}



