#ifndef PROCESSMANAGER_H
#define PROCESSMANAGER_H

#include <stdbool.h>

// Enum to represent the process state
typedef enum {
    UNUSED,
    EMBRYO,
    SLEEPING,
    BLOCKED = SLEEPING,
    RUNNABLE,
    READY = RUNNABLE,
    RUNNING,
    ZOMBIE
} processState;

#define NPROC 64            // Maximum number of concurrent processes
#define PROCESS_MAX 100     // Maximum number of processes


// Structure to represent a process
typedef struct {
    int pid;
    int parent;
    processState state;
    // Add other necessary fields for your processes
} Process;

typedef struct {
    int processCount;
    int runningProcess;
    Process processes[PROCESS_MAX];
} processStructure;

// Function prototypes
/* function prototypes */
    /* processScheduleInitialize()
     * Initialize the data structure
     */
    void processScheduleInitialize(processStructure*);
    /* processAdd()
     * Adds a new process. Returns the process id
     * or 0 if impossible
     */
    int processAdd(processStructure*, int parent);
    /* processTimerInterrupt()
     * Tells the system that an interrupt occurred. 
     * Returns the PID of the new running process
     * or -1 if none are running
     */
    int processTimerInterrupt(processStructure* ps);
    /* processIORequest()
     * Indicates that the current process has requested IO and will
     * block until it completes (see below) 
     * Returns 0 if OK, -1 otherwise.
     */
    int processIORequest(processStructure*);
    /* processIODDone()
     * Indicates that the prior request for IO By the process 
     * indicated has completed. 
     */
    int processIODone(processStructure*, int processID);
    /* processWaitFor()
     * The current process is requesting to wait for the listed 
     * process.(aka waitPid()). Returns 0 if ok, -1 unable 
     * (e.g., no such process 
     */
    
    int processWaitFor(processStructure*, int processID);
    /* processEXIT
     * Indicates that the indicated process has exited. Make sure to 
     * clean up and to kill all descendant processes. 
     * Returns 0 for success, -1 otherwise
     */
    int processExit(processStructure*, int processID);
    /* processGetRunningPID()
     * Returns the PID of the currently running process. 
     */
    int processGetRunningPID(processStructure*);
    /* returns UNUSED if no such process */
    processState getProcessStatus(processStructure*, int processID);

#endif /* PROCESSMANAGER_H */



